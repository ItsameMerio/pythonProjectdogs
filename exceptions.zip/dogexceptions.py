from food import Food   # DO NOT CHANGE THE IMPORTS. OTHERWISE THE GRADING IN A+ WONT WORK

'''
Todo: Implement the Exception classes ObjectIsNotDogObjectError and FeedingDogError.

ObjectIsNotDogObjectError should get the incorrect 'member'
tried to add. It needs to check which type it is, and tell the type in the message.

FeedingDogError is a superclass for its inheritors FeedingDogErrorMissingList, FeedingDogErrorNotFoodObject
and FeedingDogErrorObjectInListNotFoodObject.
'''

'''
Check the definitons of the classes from the exercise on A+
'''

class ObjectIsNotDogObjectError(Exception):

    #hint: use str(type())

    pass


class FeedingDogError(Exception):
    pass


class FeedingDogErrorMissingList(FeedingDogError):
    pass


class FeedingDogErrorNotFoodObject(FeedingDogError):
    pass


class FeedingDogErrorObjectInListNotFoodObject(FeedingDogError):
    pass

