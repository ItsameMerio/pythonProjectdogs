# Simple class that describes a food.
class Food:
    def __init__(self, name):
        self.name = name

    def get_food_name(self):
        return self.name



